# Comissão Pro — backend inicial

Este pacote é um backend executável, não apenas uma tela HTML.

## O que funciona nesta versão
- API para registrar comissões reais.
- Resumo de valores confirmados, pendentes e cancelados.
- Histórico.
- Importação de relatórios CSV de Mercado Livre e Shopee.
- Proteção contra duplicação de registros iguais.
- Agendador em segundo plano que registra batimentos e status dos conectores.

## O que ainda não está conectado
Não há credenciais nem integração direta com as contas de afiliado. O agendador **não** inventa vendas nem acessa contas. A conexão automática só poderá ser ativada com API/documentação oficial disponível e autorização da plataforma/conta.

## Executar com Docker
```bash
docker compose up --build
```
Depois abra:
- `http://localhost:8000/health`
- `http://localhost:8000/docs`

## Executar sem Docker
```bash
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# Linux/macOS: source .venv/bin/activate
pip install -r requirements.txt
uvicorn app.main:app --host 0.0.0.0 --port 8000
```

## Importar CSV
Use `POST /import/mercado-livre` ou `POST /import/shopee` com um arquivo CSV UTF-8.
Cabeçalhos mínimos: `valor,status`. Opcionais: `referencia,data`.
Valores aceitos em status: `Pendente`, `Confirmada`, `Cancelada`.
Exemplo:
```csv
referencia;valor;status;data
pedido-123;12,50;Pendente;2026-11-21
```

## Endpoints
- `GET /` abre o painel web integrado.
- `GET /health`
- `GET /summary`
- `GET /commissions`
- `POST /commissions`
- `POST /import/mercado-livre`
- `POST /import/shopee`
- `GET /sync-status`

## Próxima fase
Hospedar em servidor com HTTPS, autenticação de usuário e segredos protegidos; em seguida implementar cada conector somente com interfaces oficiais autorizadas.
